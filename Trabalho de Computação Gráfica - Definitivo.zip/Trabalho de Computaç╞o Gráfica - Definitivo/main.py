import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import glm
import ctypes
import pywavefront
import os
from PIL import Image
import pygame

def init_glfw():
    """Inicializar GLFW"""
    if not glfw.init():
        raise Exception("GLFW não iniciou")
    
    # Configurar versão OpenGL
    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)
    
    return True

def create_window(width=1280, height=720, title="Trabalho de Computação Gráfica - Posto de Gasolina 3D."):
    """Criar janela GLFW"""
    window = glfw.create_window(width, height, title, None, None)
    if not window:
        glfw.terminate()
        raise Exception("Falha ao criar janela")
    
    glfw.make_context_current(window)
    glfw.set_input_mode(window, glfw.CURSOR, glfw.CURSOR_DISABLED)
    
    return window

def create_shader(shader_type, source):
    """Criar e compilar shader"""
    shader = glCreateShader(shader_type)
    glShaderSource(shader, source)
    glCompileShader(shader)
    
    if not glGetShaderiv(shader, GL_COMPILE_STATUS):
        info_log = glGetShaderInfoLog(shader)
        raise Exception(f"Erro de compilação do shader: {info_log.decode()}")
    
    return shader

def create_shader_program():
    """Criar programa de shader"""
    vertex_shader_source = """
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 aNormal;
    layout (location = 2) in vec2 aTexCoords;

    out vec3 FragPos;
    out vec3 Normal;
    out vec2 TexCoords;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        FragPos = vec3(model * vec4(aPos, 1.0));
        Normal = mat3(transpose(inverse(model))) * aNormal;
        TexCoords = aTexCoords;
        gl_Position = projection * view * vec4(FragPos, 1.0);
    }
    """

    fragment_shader_source = """
    #version 330 core
    out vec4 FragColor;

    in vec3 FragPos;
    in vec3 Normal;
    in vec2 TexCoords;

    uniform vec3 viewPos;
    uniform vec3 objectColor;
    uniform sampler2D texture_diffuse1;
    uniform bool useTexture;

    uniform vec3 lightPos;
    uniform vec3 lightColor;

    uniform vec3 lightPos2;
    uniform vec3 lightColor2;

    void main()
    {
        vec3 baseColor = objectColor;
        if (useTexture){
            vec4 texColor = texture(texture_diffuse1, TexCoords);
            if (texColor.a < 0.1) discard;
            baseColor = texColor.rgb;
        }

        float ambientStrength = 0.3;
        vec3 ambient = ambientStrength * vec3(1.0);

        // --- LUZ 1 ---
        vec3 norm = normalize(Normal);
        vec3 lightDir1 = normalize(lightPos - FragPos);
        float diff1 = max(dot(norm, lightDir1), 0.0);
        vec3 diffuse1 = diff1 * lightColor;

        float specularStrength1 = 0.5;
        vec3 viewDir = normalize(viewPos - FragPos);
        vec3 reflectDir1 = reflect(-lightDir1, norm);
        float spec1 = pow(max(dot(viewDir, reflectDir1), 0.0), 32);
        vec3 specular1 = specularStrength1 * spec1 * lightColor;

        // --- LUZ 2 ---
        vec3 lightDir2 = normalize(lightPos2 - FragPos);
        float diff2 = max(dot(norm, lightDir2), 0.0);
        vec3 diffuse2 = diff2 * lightColor2;
        
        float specularStrength2 = 0.2; 
        vec3 reflectDir2 = reflect(-lightDir2, norm);
        float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 16);
        vec3 specular2 = specularStrength2 * spec2 * lightColor2;

        // Componentes de iluminação combinados.
        vec3 lighting = ambient + diffuse1 + specular1 + diffuse2 + specular2;
        vec3 result = lighting * baseColor;
        FragColor = vec4(result, 1.0);
    }
    """
    
    vertex_shader = create_shader(GL_VERTEX_SHADER, vertex_shader_source)
    fragment_shader = create_shader(GL_FRAGMENT_SHADER, fragment_shader_source)
    
    shader_program = glCreateProgram()
    glAttachShader(shader_program, vertex_shader)
    glAttachShader(shader_program, fragment_shader)
    glLinkProgram(shader_program)
    
    if not glGetProgramiv(shader_program, GL_LINK_STATUS):
        info_log = glGetProgramInfoLog(shader_program)
        raise Exception(f"Erro de linkagem do shader program: {info_log.decode()}")
    
    glDeleteShader(vertex_shader)
    glDeleteShader(fragment_shader)
    
    return shader_program

def create_skybox_shader_program():
    """Criar programa de shader para o skybox"""
    vertex_shader_source = """
    #version 330 core
    layout (location = 0) in vec3 aPos;
    
    out vec3 TexCoords;
    
    uniform mat4 projection;
    uniform mat4 view;
    
    void main()
    {
        TexCoords = aPos;
        vec4 pos = projection * view * vec4(aPos, 1.0);
        gl_Position = pos.xyww;
    }
    """

    fragment_shader_source = """
    #version 330 core
    in vec3 TexCoords;
    out vec4 FragColor;
    
    uniform samplerCube skybox;
    
    void main()
    {     
        FragColor = texture(skybox, TexCoords);
    }
    """
    
    vertex_shader = create_shader(GL_VERTEX_SHADER, vertex_shader_source)
    fragment_shader = create_shader(GL_FRAGMENT_SHADER, fragment_shader_source)
    
    shader_program = glCreateProgram()
    glAttachShader(shader_program, vertex_shader)
    glAttachShader(shader_program, fragment_shader)
    glLinkProgram(shader_program)
    
    if not glGetProgramiv(shader_program, GL_LINK_STATUS):
        info_log = glGetProgramInfoLog(shader_program)
        raise Exception(f"Erro de linkagem do skybox shader program: {info_log.decode()}")
    
    glDeleteShader(vertex_shader)
    glDeleteShader(fragment_shader)
    
    return shader_program

class Camera:
    """Classe para gerenciar a câmera com movimento restrito ao plano XZ"""
    def __init__(self, position=glm.vec3(0.0, 2.0, 10.0)):
        self.position = position
        self.front = glm.vec3(0.0, 0.0, -1.0)
        self.up = glm.vec3(0.0, 1.0, 0.0)
        self.speed = 0.1
        self.yaw = -90.0
        self.pitch = 0.0
        self.first_mouse = True
        self.last_x = 1280.0 / 2
        self.last_y = 720.0 / 2
        self.fixed_y = position.y

    def get_view_matrix(self):
        return glm.lookAt(self.position, self.position + self.front, self.up)
    
    def try_move(self, window, collision_checker):
        """Tenta mover a câmera verificando colisões"""
        old_position = glm.vec3(self.position)
        
        move_direction = glm.vec3(0)
        if glfw.get_key(window, glfw.KEY_W) == glfw.PRESS:
            move_direction += self.front
        if glfw.get_key(window, glfw.KEY_S) == glfw.PRESS:
            move_direction -= self.front
        if glfw.get_key(window, glfw.KEY_A) == glfw.PRESS:
            move_direction -= glm.normalize(glm.cross(self.front, self.up))
        if glfw.get_key(window, glfw.KEY_D) == glfw.PRESS:
            move_direction += glm.normalize(glm.cross(self.front, self.up))
        
        if glm.length(move_direction) > 0:
            flat_move = glm.normalize(glm.vec3(move_direction.x, 0.0, move_direction.z))
            new_position = self.position + flat_move * self.speed
            new_position.y = self.position.y
            
            collided, _ = collision_checker(new_position)
            if not collided:
                self.position = new_position
            else:
                x_only_position = glm.vec3(new_position.x, self.fixed_y, old_position.z)
                collided_x, _ = collision_checker(x_only_position)
                if not collided_x:
                    self.position = x_only_position
                else:
                    z_only_position = glm.vec3(old_position.x, self.fixed_y, new_position.z)
                    collided_z, _ = collision_checker(z_only_position)
                    if not collided_z:
                        self.position = z_only_position

    def process_mouse(self, window, xpos, ypos):
        if self.first_mouse:
            self.last_x = xpos
            self.last_y = ypos
            self.first_mouse = False
        
        xoffset = xpos - self.last_x
        yoffset = self.last_y - ypos
        self.last_x = xpos
        self.last_y = ypos
        
        sensitivity = 0.1
        xoffset *= sensitivity
        yoffset *= sensitivity
        
        self.yaw += xoffset
        self.pitch += yoffset
        
        self.pitch = max(-89.0, min(89.0, self.pitch))
        
        direction = glm.vec3()
        direction.x = glm.cos(glm.radians(self.yaw)) * glm.cos(glm.radians(self.pitch))
        direction.y = glm.sin(glm.radians(self.pitch))
        direction.z = glm.sin(glm.radians(self.yaw)) * glm.cos(glm.radians(self.pitch))
        self.front = glm.normalize(direction)

class CollisionSystem:
    """Sistema de detecção de colisão AABB"""
    def __init__(self):
        self.aabbs = {}
        self.player_radius = 0.5
    
    def add_aabb(self, name, min_coords, max_coords):
        """Adicionar uma AABB ao sistema"""
        self.aabbs[name] = {'min': min_coords, 'max': max_coords}
    
    def check_collision(self, player_pos):
        """Verificar colisão do jogador com todos os objetos"""
        for name, aabb in self.aabbs.items():
            if self._point_in_aabb_with_radius(player_pos, aabb['min'], aabb['max'], self.player_radius):
                return True, name
        return False, None
    
    def _point_in_aabb_with_radius(self, point, aabb_min, aabb_max, radius):
        # Expande a caixa para considerar o "raio" do jogador.
        expanded_min = aabb_min - glm.vec3(radius, 0, radius)
        expanded_max = aabb_max + glm.vec3(radius, 0, radius)
        # Verifica se o ponto está dentro da caixa expandida.
        return (point.x >= expanded_min.x and point.x <= expanded_max.x and
                point.y >= aabb_min.y and point.y <= aabb_max.y and
                point.z >= expanded_min.z and point.z <= expanded_max.z)

class Skybox:
    """Classe para renderizar um skybox/cubemap"""
    def __init__(self, faces):
        self.faces = faces
        self.texture_id = self.load_cubemap(faces)
        self.vao, self.vbo = self.setup_skybox()

    def load_cubemap(self, faces):
        """Carregar textura do cubemap a partir de 6 imagens"""
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_CUBE_MAP, texture_id)

        for i in range(len(faces)):
            try:
                img = Image.open(faces[i])
                img_data = img.convert("RGB").tobytes()
                width, height = img.size
                glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB, 
                             width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
            except Exception as e:
                print(f"Erro ao carregar textura do skybox: {faces[i]}\n{e}")
                pass

        glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE)

        return texture_id

    def setup_skybox(self):
        """Configurar geometria do skybox (um cubo grande)"""
        skybox_vertices = np.array([
            -1.0,  1.0, -1.0, -1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0,  1.0, -1.0, -1.0,  1.0, -1.0,
            -1.0, -1.0,  1.0, -1.0, -1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0,  1.0, -1.0, -1.0,  1.0,
             1.0, -1.0, -1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0, -1.0, -1.0,
            -1.0, -1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0, -1.0, -1.0,  1.0,
            -1.0,  1.0, -1.0,  1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0,  1.0, -1.0,  1.0, -1.0,
            -1.0, -1.0, -1.0, -1.0, -1.0,  1.0,  1.0, -1.0, -1.0,  1.0, -1.0, -1.0, -1.0, -1.0,  1.0,  1.0, -1.0,  1.0
        ], dtype=np.float32)

        vao = glGenVertexArrays(1)
        vbo = glGenBuffers(1)
        glBindVertexArray(vao)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, skybox_vertices.nbytes, skybox_vertices, GL_STATIC_DRAW)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), ctypes.c_void_p(0))
        glEnableVertexAttribArray(0)
        glBindVertexArray(0)
        return vao, vbo

    def render(self, shader_program, view_matrix, projection_matrix):
        """Renderizar o skybox"""
        glDepthFunc(GL_LEQUAL)
        glUseProgram(shader_program)
        view = glm.mat4(glm.mat3(view_matrix))
        glUniformMatrix4fv(glGetUniformLocation(shader_program, "view"), 1, GL_FALSE, glm.value_ptr(view))
        glUniformMatrix4fv(glGetUniformLocation(shader_program, "projection"), 1, GL_FALSE, glm.value_ptr(projection_matrix))
        glBindVertexArray(self.vao)
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_CUBE_MAP, self.texture_id)
        glDrawArrays(GL_TRIANGLES, 0, 36)
        glBindVertexArray(0)
        glDepthFunc(GL_LESS)

class Model:
    def __init__(self, obj_path, collision_system, texture_path=None, is_ground=False):
        self.obj_path = obj_path
        self.texture_path = texture_path
        self.is_ground = is_ground
        self.texture_id = None  
        self.scene = None
        self.vaos = []
        self.vbos = []
        self.materials_data = []
        self.collision_system = collision_system
        self.load_model()
        
        if self.texture_path:
            self.texture_id = self.load_texture(self.texture_path)

    def load_texture(self, filename):
        try:
            img = Image.open(filename)
            img = img.transpose(Image.FLIP_TOP_BOTTOM)
            img_data = img.convert("RGBA").tobytes()
            width, height = img.size

            tex_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, tex_id)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
            glGenerateMipmap(GL_TEXTURE_2D)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glBindTexture(GL_TEXTURE_2D, 0)
            return tex_id
        except FileNotFoundError:
            print(f"Arquivo de textura não encontrado: {filename}")
            return None
    
    def load_model(self):
        """Carregar modelo OBJ usando PyWavefront"""
        try:
            self.scene = pywavefront.Wavefront(self.obj_path, collect_faces=True, parse=True, create_materials=True)
            self.process_materials()
        except Exception as e:
            print(f"Erro ao carregar modelo {self.obj_path}: {e}")
            self.scene = None
    
    def add_collision_to_system(self, model_matrix, name_prefix=""):
        """Calcula a AABB no espaço do mundo e a adiciona ao sistema de colisão"""
        if not self.scene:
            return

        for material_name, material in self.scene.materials.items():
            vertices_data_raw = self.extract_vertices_data_raw(material)
            if not vertices_data_raw:
                continue
            
            min_coords_world = glm.vec3(float('inf'))
            max_coords_world = glm.vec3(float('-inf'))
            
            for i in range(0, len(vertices_data_raw), 3):
                local_vertex = glm.vec3(vertices_data_raw[i], vertices_data_raw[i+1], vertices_data_raw[i+2])
                world_vertex_h = model_matrix * glm.vec4(local_vertex, 1.0)
                world_vertex = glm.vec3(world_vertex_h)
                
                min_coords_world = glm.min(min_coords_world, world_vertex)
                max_coords_world = glm.max(max_coords_world, world_vertex)
            
            unique_aabb_name = f"{name_prefix}_{os.path.basename(self.obj_path)}_{material_name}"
            self.collision_system.add_aabb(unique_aabb_name, min_coords_world, max_coords_world)
    
    def process_materials(self):
        """Processar materiais e criar VAOs/VBOs"""
        if not self.scene:
            return
        
        for material_name, material in self.scene.materials.items():
            if not material.vertices:
                continue
            
            vertices_data_processed = self.extract_vertices_data_processed(material)
            if not vertices_data_processed:
                continue
            
            vao, vbo = self.create_vao_vbo(vertices_data_processed)
            
            color = glm.vec3(0.7, 0.7, 0.7)
            if material.diffuse:
                color = glm.vec3(material.diffuse[0], material.diffuse[1], material.diffuse[2])
            
            self.vaos.append(vao)
            self.vbos.append(vbo)
            self.materials_data.append({
                'name': material_name,
                'vertex_count': len(vertices_data_processed) // 8,
                'color': color
            })
    
    def extract_vertices_data_raw(self, material):
        """Extrair apenas dados de posição (V3F) para cálculo de AABB"""
        vertices_data = []
        if not material.vertices:
            return vertices_data

        format_parts = material.vertex_format.split('_')
        stride = sum([int(p[1]) for p in format_parts])
        
        pos_offset = -1
        current_offset = 0
        for i, part in enumerate(format_parts):
            if 'V3F' in part:
                pos_offset = current_offset
                break
            current_offset += int(part[1])

        if pos_offset == -1:
             return []

        for i in range(len(material.vertices) // stride):
            base_idx = i * stride + pos_offset
            vertices_data.extend(material.vertices[base_idx:base_idx+3])
            
        return vertices_data

    def extract_vertices_data_processed(self, material):
        """Extrair dados de vértices do material para VAO (Pos, Normal, TexCoord)"""
        vertices_data = []
        if not material.vertices: return vertices_data
        
        format_parts = material.vertex_format.split('_')
        stride = sum([int(p[1]) for p in format_parts])

        offsets = {}
        current_offset = 0
        for part in format_parts:
            if 'V3F' in part: offsets['V3F'] = current_offset
            if 'N3F' in part: offsets['N3F'] = current_offset
            if 'T2F' in part: offsets['T2F'] = current_offset
            current_offset += int(part[1])

        for i in range(len(material.vertices) // stride):
            base_idx = i * stride
            
            pos = material.vertices[base_idx + offsets.get('V3F', 0) : base_idx + offsets.get('V3F', 0) + 3] if 'V3F' in offsets else [0,0,0]
            normal = material.vertices[base_idx + offsets.get('N3F', 0) : base_idx + offsets.get('N3F', 0) + 3] if 'N3F' in offsets else [0,1,0]
            texcoord = material.vertices[base_idx + offsets.get('T2F', 0) : base_idx + offsets.get('T2F', 0) + 2] if 'T2F' in offsets else [0,0]

            vertices_data.extend(pos)
            vertices_data.extend(normal)

            if self.is_ground:
                vertices_data.extend([texcoord[0] * 10.0, texcoord[1] * 10.0])
            else:
                vertices_data.extend(texcoord)
    
        return vertices_data
    
    def create_vao_vbo(self, vertices_data):
        """Criar VAO e VBO para os dados de vértices"""
        vertices_np = np.array(vertices_data, dtype=np.float32)
        
        vao = glGenVertexArrays(1)
        vbo = glGenBuffers(1)
        
        glBindVertexArray(vao)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, vertices_np.nbytes, vertices_np, GL_STATIC_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), ctypes.c_void_p(0))
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), ctypes.c_void_p(3 * sizeof(GLfloat)))
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), ctypes.c_void_p(6 * sizeof(GLfloat)))
        glEnableVertexAttribArray(2)
        
        glBindVertexArray(0)
        return vao, vbo
    
    def render(self, shader_program, model_matrix=glm.mat4(1.0)):
        if not self.scene or not self.vaos:
            return

        glUseProgram(shader_program)
        model_loc = glGetUniformLocation(shader_program, "model")
        object_color_loc = glGetUniformLocation(shader_program, "objectColor")
        use_texture_loc = glGetUniformLocation(shader_program, "useTexture")

        glUniformMatrix4fv(model_loc, 1, GL_FALSE, glm.value_ptr(model_matrix))

        for i, vao in enumerate(self.vaos):
            material_data = self.materials_data[i]
            
            if self.texture_id:
                glActiveTexture(GL_TEXTURE0)
                glBindTexture(GL_TEXTURE_2D, self.texture_id)
                glUniform1i(glGetUniformLocation(shader_program, "texture_diffuse1"), 0)
                glUniform1i(use_texture_loc, GL_TRUE)
            else:
                glUniform1i(use_texture_loc, GL_FALSE)
                glUniform3fv(object_color_loc, 1, glm.value_ptr(material_data['color']))

            glBindVertexArray(vao)
            glDrawArrays(GL_TRIANGLES, 0, material_data['vertex_count'])
            glBindVertexArray(0)

            if self.texture_id:
                glBindTexture(GL_TEXTURE_2D, 0)
    
    def cleanup(self):
        """Limpar recursos"""
        if self.vbos: glDeleteBuffers(len(self.vbos), self.vbos)
        if self.vaos: glDeleteVertexArrays(len(self.vaos), self.vaos)

def main():
    """Função principal"""
    obj_file_posto = 'modelos/posto.obj'
    obj_file_asfalto = 'modelos/asfalto.obj'
    obj_file_trash = 'modelos/trash.obj'
    obj_file_car = 'modelos/car.obj' 
    texture_file_car = 'modelos/carjeep.jpg'
    obj_file_garagem = 'modelos/garagem.obj'
    texture_file_garagem = 'modelos/garage_3.png'
    music_file = 'músicas/sound1.mp3'

    required_files = [obj_file_posto, obj_file_asfalto, obj_file_car, texture_file_car, obj_file_garagem, texture_file_garagem]
    for f in required_files:
        if not os.path.exists(f):
            raise FileNotFoundError(f"Arquivo essencial não encontrado: {f}")
            
    music_enabled = True
    if not os.path.exists(music_file):
        print(f"AVISO: Arquivo de música não encontrado em '{music_file}'. A aplicação continuará sem som.")
        music_enabled = False

    init_glfw()
    window = create_window()
    
    if music_enabled:
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(music_file)
        pygame.mixer.music.set_volume(0.1)

    collision_system = CollisionSystem()
    camera = Camera(position=glm.vec3(0.0, 2.0, 15.0))
    glfw.set_cursor_pos_callback(window, camera.process_mouse)

    shader_program = create_shader_program()
    skybox_shader = create_skybox_shader_program()
    
    skybox_faces = ['skybox/right.png', 'skybox/left.png', 'skybox/top.png', 'skybox/bottom.png', 'skybox/front.png', 'skybox/back.png']
    skybox = Skybox(skybox_faces)

    model_posto = Model(obj_file_posto, collision_system)
    model_asfalto = Model(obj_file_asfalto, collision_system, texture_path='modelos/black-road-texture.jpeg')
    model_trash = Model(obj_file_trash, collision_system, texture_path="modelos/trash bag_uw_BaseColor.png")
    model_trash2 = Model("modelos/trash2.obj", collision_system, texture_path="modelos/textura-lata-lixo.jpg")
    model_chao = Model(obj_file_asfalto, collision_system, texture_path='modelos/grafico-decorativo-grao-antigo.jpg', is_ground=True)
    model_car = Model(obj_file_car, collision_system, texture_path=texture_file_car)
    model_garagem = Model(obj_file_garagem, collision_system, texture_path=texture_file_garagem)

    posto_transform = glm.translate(glm.mat4(1.0), glm.vec3(0.0, -0.5, 0.0))
    trash_transform1 = glm.translate(glm.mat4(1.0), glm.vec3(7.5, -0.5, -2.0))
    trash_transform2 = glm.translate(glm.mat4(1.0), glm.vec3(7.5, -0.5, -3.0))
    trash2_transform = glm.translate(glm.mat4(1.0), glm.vec3(7.5, -0.5, -5.0)) * glm.rotate(glm.mat4(1.0), glm.radians(90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.4, 0.4, 0.4))
    chao_transform = glm.translate(glm.mat4(1.0), glm.vec3(2.0, -0.6, 0.0)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(12.0, 1.0, 4.0))
    garagem_transform = glm.translate(glm.mat4(1.0), glm.vec3(50.5, -0.25, 2.5)) * glm.rotate(glm.mat4(1.0), glm.radians(180), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(1.5, 1.5, 1.5))

    car_transforms = [
        glm.translate(glm.mat4(1.0), glm.vec3(12.0, 0.35, 6.5)) * glm.rotate(glm.mat4(1.0), glm.radians(-135), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(1.0, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-20.0, 0.35, 12.0)) * glm.rotate(glm.mat4(1.0), glm.radians(90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(1.0, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-18.5, 0.35, 41.0)) * glm.rotate(glm.mat4(1.0), glm.radians(100), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(1.0, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(42.0, 0.35, 4.0)) * glm.rotate(glm.mat4(1.0), glm.radians(-180), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(1.0, 1.0, 1.0))
    ]
    asfalto_transforms = [
        glm.translate(glm.mat4(1.0), glm.vec3(23.5, 0.1, 2.5)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-5.0, 0.1, 7.5)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-5.0, 0.1, 12.5)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(2.0, -0.5, -9.4)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 0.5)),
        glm.translate(glm.mat4(1.0), glm.vec3(-12.5, -0.2, -9.4)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.rotate(glm.mat4(1.0), glm.radians(-2), glm.vec3(1, 0, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 0.4)),
        glm.translate(glm.mat4(1.0), glm.vec3(11.5, -0.25, -5.8)) * glm.rotate(glm.mat4(1.0), glm.radians(-3), glm.vec3(1, 0, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 0.35)),
        glm.translate(glm.mat4(1.0), glm.vec3(14.0, 0.1, 23.0)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.1)),
        glm.translate(glm.mat4(1.0), glm.vec3(42.5, 0.1, 2.0)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(42.5, 0.1, -30.5)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(42.5, 0.1, 34.5)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(25.0, 0.1, 41.0)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-7.5, 0.1, 41.0)) * glm.rotate(glm.mat4(1.0), glm.radians(-90), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-21.5, 0.1, 34.5)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0)),
        glm.translate(glm.mat4(1.0), glm.vec3(-21.5, 0.1, 2.0)) * glm.rotate(glm.mat4(1.0), glm.radians(0), glm.vec3(0, 1, 0)) * glm.scale(glm.mat4(1.0), glm.vec3(0.5, 1.0, 1.0))
    ]

    print("Calculando caixas de colisão...")
    model_posto.add_collision_to_system(posto_transform, name_prefix="posto")
    model_garagem.add_collision_to_system(garagem_transform, name_prefix="garagem")
    model_trash.add_collision_to_system(trash_transform1, name_prefix="trash1")
    model_trash.add_collision_to_system(trash_transform2, name_prefix="trash2")
    model_trash2.add_collision_to_system(trash2_transform, name_prefix="trash_can")
    model_chao.add_collision_to_system(chao_transform, name_prefix="chao_grama")

    for i, transform in enumerate(car_transforms):
        model_car.add_collision_to_system(transform, name_prefix=f"car_{i}")
    
    for i, transform in enumerate(asfalto_transforms):
        model_asfalto.add_collision_to_system(transform, name_prefix=f"asfalto_{i}")
        
    print("Caixas de colisão calculadas.")
    
    def check_camera_collision(position):
        collided, object_name = collision_system.check_collision(position)
        return collided, object_name

    glUseProgram(shader_program)
    projection_matrix = glm.perspective(glm.radians(45.0), 1280.0 / 720.0, 0.1, 100.0)
    glUniformMatrix4fv(glGetUniformLocation(shader_program, "projection"), 1, GL_FALSE, glm.value_ptr(projection_matrix))
    glUniform3f(glGetUniformLocation(shader_program, "lightPos"), 5.0, 5.0, 5.0)
    glUniform3f(glGetUniformLocation(shader_program, "lightColor"), 1.0, 1.0, 1.0)
    glUniform3f(glGetUniformLocation(shader_program, "lightPos2"), -8.0, 4.0, -6.0) 
    glUniform3f(glGetUniformLocation(shader_program, "lightColor2"), 0.6, 0.6, 0.6)

    glEnable(GL_DEPTH_TEST)
    glClearColor(0.2, 0.2, 0.2, 1.0)

    print("-> POSTO DE GASOLINA 3D COM DETECÇÃO DE COLISÃO <-")
    print("Controles:")
    print("  WASD - Mover câmera (plano XZ)")
    print("  Espaço - Subir")
    print("  Shift Esquerdo - Descer até Y mínimo")
    print("  Mouse - Olhar ao redor")
    print("  ESC - Sair")

    music_started = False
    start_time = glfw.get_time()
    delay_seconds = 0.5

    while not glfw.window_should_close(window):
        if music_enabled and not music_started:
            current_time = glfw.get_time()
            if current_time - start_time >= delay_seconds:
                pygame.mixer.music.play(-1)
                music_started = True

        glfw.poll_events()
        camera.try_move(window, check_camera_collision)

        if glfw.get_key(window, glfw.KEY_SPACE) == glfw.PRESS:
            camera.position.y += camera.speed
        if glfw.get_key(window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS or glfw.get_key(window, glfw.KEY_E) == glfw.PRESS:
            camera.position.y = max(camera.fixed_y, camera.position.y - camera.speed)
        if glfw.get_key(window, glfw.KEY_ESCAPE) == glfw.PRESS:
            glfw.set_window_should_close(window, True)

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        view_matrix = camera.get_view_matrix()
        
        skybox.render(skybox_shader, view_matrix, projection_matrix)
        
        glUseProgram(shader_program)
        glUniformMatrix4fv(glGetUniformLocation(shader_program, "view"), 1, GL_FALSE, glm.value_ptr(view_matrix))
        glUniform3fv(glGetUniformLocation(shader_program, "viewPos"), 1, glm.value_ptr(camera.position))

        model_posto.render(shader_program, model_matrix=posto_transform)
        model_trash.render(shader_program, model_matrix=trash_transform1)
        model_trash.render(shader_program, model_matrix=trash_transform2)
        model_trash2.render(shader_program, model_matrix=trash2_transform)
        model_chao.render(shader_program, model_matrix=chao_transform)
        model_garagem.render(shader_program, model_matrix=garagem_transform)

        for transform in car_transforms:
            model_car.render(shader_program, model_matrix=transform)

        for transform in asfalto_transforms:
            model_asfalto.render(shader_program, model_matrix=transform)

        glfw.swap_buffers(window)

    model_posto.cleanup()
    model_asfalto.cleanup()
    model_trash.cleanup()
    model_trash2.cleanup()
    model_chao.cleanup()
    model_car.cleanup()
    model_garagem.cleanup()
    glDeleteProgram(shader_program)
    glDeleteProgram(skybox_shader)
    
    if music_enabled:
        pygame.mixer.music.stop()
        pygame.quit()
        
    glfw.terminate()

if __name__ == "__main__":
    main()