Link para as texturas do skybox: https://drive.google.com/drive/folders/1FJ_GvMSybZs_rSQlAddNTDou-nTKFtZE?usp=drive_link

Link para a música executada no projeto: https://drive.google.com/drive/folders/1zo9qLYm6lhejxjxKgfE_vNJw5zmPTWG-?usp=drive_link


Adicionadas no drive devido o arquivo não chegar aos 10mb com elas no projeto!